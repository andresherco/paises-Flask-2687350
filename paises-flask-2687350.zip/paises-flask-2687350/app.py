#Importar la clase dependencia en Flask
from flask import Flask,  render_template

#Crear el objeto Flask en la app
app = Flask(__name__)

#Crear la primra ruta de flask
@app.route('/paises')
def paises():
    
    paises = [
       ' Colombia '
       ' Peru '
       ' chile '
       ' brazil '
       ' china '
    ]
    

    
    continentes = [
        {
         "nombre" : "America",
         "poblacion" : "mil millones",
         "superficie" : "42.5 millones km²",
         "paises" : [
             
             {
                 "nom" : "Colombia",
                 "extension" : "1.142 millones km2",
                 "cap"  : "Bogota",
                 "mon" : "Peso",
                 "pob" : 51 
                 
                 },
             {
                 "nom" : "Peru",
                 "extension" : "1.285 millones km2",
                 "cap"  : "Lima",
                 "mon" : "Sol",
                 "pob" : 33
                 
                 },
             {
                "nom" : "Paraguay",
                "extension" : "406 millones km2",
                "cap"  : "Asuncion",
                "mon" : "Guarani",
                "pob" : 7          
             }
             
          ]
         },
        {
        "nombre" : "Europa",
        "poblacion" : "746 millones",
        "superficie" : "10,53 millones km²",
        "paises" : [
           {    "nom" : "España",
                "extension" : "505 millones km2",
                "cap" : "Madrid",
                "mon" : "Euro",
                "pob" : 48
             },
           {
            "nom" : "Reino Unido",
            "extension" : "1.205 millones km2",
            "cap" : "Londres",
            "mon" : "Libra Esterlina",
            "pob" : 69           
            },
         ]
        }
    ]
    
    username = "Andres Felipe "
    return render_template("paises.html", 
                           username = username ,
                            paises = paises, 
                            continentes = continentes)
